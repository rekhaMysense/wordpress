<?php
/*
Plugin Name: Git Main
Description: GitHub integration
Author: mndpsingh287
Version: 1.0.0
Author URI: https://profiles.wordpress.org/mndpsingh287
*/

define( 'MK_GIT_MAIN_PATH', WP_PLUGIN_DIR . '/' . basename( dirname( __FILE__ ) ) . '/' );
define( 'MK_GIT_MAIN_URL', plugin_dir_url( MK_GIT_MAIN_PATH ) . basename( dirname( __FILE__ ) ) . '/' );
define( 'MK_GIT_MAIN_FILE', __FILE__);
if (!defined("MK_GIT_MAIN_DIRNAME")) define("MK_GIT_MAIN_DIRNAME", plugin_basename(dirname(__FILE__)));
if(!defined('WP_34')) {
$wp_34 = false;
	if ( version_compare( get_bloginfo( 'version' ), '3.4', '>=' ) ) {
		$wp_34 = true;
	}
define( 'WP_34', $wp_34 );
}
if(!defined('WP_43')) {
	$wp_43 = false;
	if ( version_compare( get_bloginfo( 'version' ), '4.3', '>=' ) ) {
			$wp_43 = true;
	}
	define( 'WP_43', $wp_43 );
}
if(!defined('WPWINDOWS')) {
	$windows = false;
	if ( strtoupper( substr( PHP_OS, 0, 3 ) ) === 'WIN' ) {
	$windows = true;
	}
  define( 'WPWINDOWS', $windows );
}
// add_action('init', 'theme_editor_load_text_domain');
// function theme_editor_load_text_domain(){
// 	load_plugin_textdomain('theme-editor', false, MK_GIT_MAIN_DIRNAME . "/languages");
// 		}
include('app/app.php');
//include('ms_child_theme_editor.php');

use te\pa\git_main_app as run_git_main_app;
new run_git_main_app;